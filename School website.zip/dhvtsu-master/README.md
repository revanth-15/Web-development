# DHVTSU website
A school website built using HTML &amp; CSS.

This is a web activity in my Advance Web Development subject back in college. I tried to improve the website and made it responsive using media queries.
